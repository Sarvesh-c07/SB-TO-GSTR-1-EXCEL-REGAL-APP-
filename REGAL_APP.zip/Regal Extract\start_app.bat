@echo off
setlocal
cd /d "%~dp0"
python -c "import openpyxl, pdfplumber, pypdf" >nul 2>&1
if errorlevel 1 (
  echo Required Python packages are missing.
  echo Run setup_and_start.bat once, then use this launcher.
  pause
  exit /b 1
)
python app.py
if errorlevel 1 pause
