@echo off
setlocal
cd /d "%~dp0"
echo Installing the local open-source document libraries...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Setup could not finish. Check your Python installation and internet connection.
  pause
  exit /b 1
)
python app.py
if errorlevel 1 pause
